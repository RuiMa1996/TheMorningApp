﻿namespace TheMorningApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.IP = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CityName = new System.Windows.Forms.Label();
            this.IPName = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.CountryName = new System.Windows.Forms.Label();
            this.ProvinceName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Temp = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Exchange = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(322, -19);
            this.label1.Margin = new System.Windows.Forms.Padding(10);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10);
            this.label1.Size = new System.Drawing.Size(363, 78);
            this.label1.TabIndex = 0;
            this.label1.Text = "Good Morning";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 3;
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.Location = new System.Drawing.Point(441, 54);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(125, 39);
            this.UserName.TabIndex = 2;
            this.UserName.Text = "Rui Ma";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-3, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(239, 36);
            this.label4.TabIndex = 4;
            this.label4.Text = "Your Location is:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(-3, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 36);
            this.label5.TabIndex = 6;
            this.label5.Text = "Province";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(-3, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 36);
            this.label6.TabIndex = 7;
            this.label6.Text = "City";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-3, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 36);
            this.label7.TabIndex = 9;
            this.label7.Text = "Country";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // IP
            // 
            this.IP.AutoSize = true;
            this.IP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IP.Location = new System.Drawing.Point(-3, 339);
            this.IP.Name = "IP";
            this.IP.Size = new System.Drawing.Size(162, 36);
            this.IP.TabIndex = 11;
            this.IP.Text = "IP Address";
            this.IP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(330, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 36);
            this.label8.TabIndex = 12;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CityName
            // 
            this.CityName.AutoSize = true;
            this.CityName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityName.Location = new System.Drawing.Point(330, 283);
            this.CityName.Name = "CityName";
            this.CityName.Size = new System.Drawing.Size(66, 36);
            this.CityName.TabIndex = 13;
            this.CityName.Text = "City";
            this.CityName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // IPName
            // 
            this.IPName.AutoSize = true;
            this.IPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IPName.Location = new System.Drawing.Point(330, 339);
            this.IPName.Name = "IPName";
            this.IPName.Size = new System.Drawing.Size(154, 36);
            this.IPName.TabIndex = 14;
            this.IPName.Text = "IPAddress";
            this.IPName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(330, 222);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 36);
            this.label11.TabIndex = 15;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CountryName
            // 
            this.CountryName.AutoSize = true;
            this.CountryName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountryName.Location = new System.Drawing.Point(330, 160);
            this.CountryName.Name = "CountryName";
            this.CountryName.Size = new System.Drawing.Size(120, 36);
            this.CountryName.TabIndex = 16;
            this.CountryName.Text = "Country";
            this.CountryName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProvinceName
            // 
            this.ProvinceName.AutoSize = true;
            this.ProvinceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProvinceName.Location = new System.Drawing.Point(330, 222);
            this.ProvinceName.Name = "ProvinceName";
            this.ProvinceName.Size = new System.Drawing.Size(132, 36);
            this.ProvinceName.TabIndex = 17;
            this.ProvinceName.Text = "Province";
            this.ProvinceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-3, 395);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 36);
            this.label3.TabIndex = 18;
            this.label3.Text = "Local Temperature";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Temp
            // 
            this.Temp.AutoSize = true;
            this.Temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temp.Location = new System.Drawing.Point(330, 395);
            this.Temp.Name = "Temp";
            this.Temp.Size = new System.Drawing.Size(182, 36);
            this.Temp.TabIndex = 19;
            this.Temp.Text = "Temperature";
            this.Temp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(-3, 453);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 36);
            this.label9.TabIndex = 20;
            this.label9.Text = "Exchange Rate";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Exchange
            // 
            this.Exchange.AutoSize = true;
            this.Exchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exchange.Location = new System.Drawing.Point(330, 453);
            this.Exchange.Name = "Exchange";
            this.Exchange.Size = new System.Drawing.Size(148, 36);
            this.Exchange.TabIndex = 21;
            this.Exchange.Text = "Exchange";
            this.Exchange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 578);
            this.Controls.Add(this.Exchange);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Temp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ProvinceName);
            this.Controls.Add(this.CountryName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.IPName);
            this.Controls.Add(this.CityName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.IP);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label UserName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label IP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label CityName;
        private System.Windows.Forms.Label IPName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label CountryName;
        private System.Windows.Forms.Label ProvinceName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Temp;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Exchange;
    }
}

